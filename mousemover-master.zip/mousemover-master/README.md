# mousemover
C++ QT project to keep mouse moving every specific amount of seconds
